import { CanonItem, WorkContent } from "@/lib/types"


async function jsonOrThrow<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const msg = await res.text().catch(() => "")
    throw new Error(`HTTP ${res.status}: ${msg || res.statusText}`)
  }
  return res.json()
}

// LIST (optionally by item_type)
export async function listCanonItems(item_type?: string) {
  const qs = item_type ? `?item_type=${encodeURIComponent(item_type)}` : ""
  const res = await fetch(`/api/canon${qs}`, { cache: "no-store" })
  return jsonOrThrow<CanonItem<WorkContent>[]>(res)
}

// CREATE
export async function createCanonItem(input: { item_type: "work"; title: string; position: number; content: WorkContent }) {
  const res = await fetch(`/api/canon`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  })
  return jsonOrThrow<CanonItem<WorkContent>>(res)
}

// PATCH (your route.ts supports id in query and/or body)
export async function patchCanonItem(id: string, patch: { title?: string; position?: number; content?: WorkContent }) {
  const res = await fetch(`/api/canon?id=${encodeURIComponent(id)}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id, ...patch }),
  })
  return jsonOrThrow<CanonItem<WorkContent>>(res)
}

// DELETE
export async function deleteCanonItem(id: string) {
  const res = await fetch(`/api/canon?id=${encodeURIComponent(id)}`, { method: "DELETE" })
  if (res.status === 204) return
  await jsonOrThrow(res)
}
