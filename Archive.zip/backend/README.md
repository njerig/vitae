# Vitae | CSE 115A | Backend

This is an Express backend.

## Getting Started

Firstly, download packages: `npm install`

Second, set up `.env` with correct credentials and keys

Finally, run the development server: `npm run dev`